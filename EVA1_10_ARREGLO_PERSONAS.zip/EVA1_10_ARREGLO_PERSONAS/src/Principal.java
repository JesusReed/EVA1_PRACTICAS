
import java.awt.PageAttributes;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //CREAR CLASE PERSONA, Y CREAR UN AREGLO
        //QUE ALMACENE 10 PERSONAS
        Persona[] aPersonas = new Persona[5];
        Scanner sCaptu = new Scanner(System.in);
        for (int i = 0; i < aPersonas.length; i++) {
            aPersonas[i] = new Persona();
            System.out.println("Introduce tu nombre:");
            aPersonas[i].nombre = sCaptu.nextLine();   
        }
        
        //COPIA DEL ARREGLO
        Persona[] aCopias = new Persona[aPersonas.length];
        for (int i = 0; i < aPersonas.length; i++) {
            aCopias[i] = new Persona();
            aCopias[i].nombre = aPersonas[i].nombre;
            //Creamos una copia de nombre en aCopias, en vez de hacer una copia de direcciones
        }
        aCopias[3].nombre="CAMBIADO a pepe";
        imprimeArreglo(aPersonas);
        imprimeCopias(aCopias);
    }
    public static void imprimeArreglo(Persona[] args){
        for (int i = 0; i < args.length; i++) {
            System.out.println("nombre " + (i+1) +": "+ args[i].nombre );
        }
    }
    public static void imprimeCopias(Persona[] args){
        for (int i = 0; i < args.length; i++) {
            System.out.println("COPIA nombre " + (i+1) +": "+ args[i].nombre );
        }
    }
}
class Persona{
    String nombre;
}