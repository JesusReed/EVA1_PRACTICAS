/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //DECLARACIÓN
        long aiDatos[], a, b;
        int[] aiDatos2, x, y;
        //
        int aiCopia[];
        //INICIALIZACIÓN DEL ARREGLO
        aiDatos = new long[10000000];
        //LLENAR CON VALOSRES ALEATORIOS
        for (int i=0 ; i <aiDatos.length; i++){
            aiDatos[i] = (long) (Math.random()*100)+1;
            System.out.println(aiDatos[i]);
        }
        //SON OBJETOS
        //LA MEMORIA ES CONSECUTIVA
        //SON DE ACCESO ALEATORIO
        aiDatos[4]=5000;
        aiDatos[69]=500;
        //SON MUY RÁPIDOS
        //SON INMUTABLES
        
        
        int[] aiArray= new int[3];
        //SE CREA UN ARRAY
        aiArray= new int[2];
        //SE BORRA EL ARRAY ANTERIOR PARA CREAR UN ARRAY CON EL MISMO NOMBRE, CON MENOS ESPACIO
    }
    
}
