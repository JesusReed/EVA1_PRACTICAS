/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatos[] = new int[100];
        int aiCopia[] = new int[100];
        
        for (int i=0 ; i <aiDatos.length; i++){
            aiDatos[i] = (int) (Math.random()*100)+1;
            System.out.println(aiDatos[i]);
        }
        System.out.println("DATOS ORIGINALES");
        for (int i=0; i<aiDatos.length;i++){
            System.out.println("["+aiDatos+"]");
        }
        aiCopia=aiDatos;
        System.out.println("\nDATOS COPIADOS");
        for (int i=0; i<aiCopia.length;i++){
            System.out.println("["+aiCopia+"]");
        }
        //CHALE, NO SE COPIÓ EL ARRAY
    }
}